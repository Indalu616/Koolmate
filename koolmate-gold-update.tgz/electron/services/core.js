'use strict'
/**
 * Application core: wires the indexer, watcher, suggestion engine, mover and (optional) Gemini
 * together. It has no Electron dependency, so it can be unit-tested; Electron-specific behaviour
 * (popup, native notifications) is injected through `hooks`.
 */
const fs = require('fs')
const path = require('path')
const { Indexer } = require('./indexer')
const { planQuery, mergeAiPlan } = require('./queryPlanner')
const { searchFiles } = require('./search')
const { suggest, buildCatalog, courseFolderName } = require('./classifier')
const { DownloadWatcher, readDownloadSource } = require('./watcher')
const { executeMove, undoMove, assertSafeDestination } = require('./mover')
const { planOrganize } = require('./organizer')
const gemini = require('./gemini')
const demo = require('./demo')
const { uid, extOf, isInside } = require('./common')

function createCore({ store, hooks = {}, documentsDir }) {
  const noop = () => {}
  const h = { onSuggestions: noop, onNewSuggestion: noop, onAutoMoved: noop, onIndex: noop, onTask: noop, onActivity: noop, onWatchError: noop, ...hooks }

  const settings = () => store.getSettings()
  const indexer = new Indexer({ getRoots: () => settings().searchRoots, getExcluded: () => settings().excludedFolders })
  const task = (kind, step, pct, detail) => h.onTask({ kind, step, pct, detail })
  indexer.onProgress = s => { h.onIndex(s); if (s.state === 'indexing') task('index', 'scan', null, `${(s.count || 0).toLocaleString()} files`) }
  const watcher = new DownloadWatcher()
  const suggestions = new Map() // id -> suggestion
  let catalogCache = { at: 0, folders: [] }
  const invalidateCatalog = () => { catalogCache.at = 0 }

  async function getCatalog() {
    if (Date.now() - catalogCache.at < 45000) return catalogCache.folders
    const s = settings()
    const roots = [...s.destinationRoots].filter(r => { try { return fs.statSync(r).isDirectory() } catch { return false } })
    const folders = await buildCatalog(roots, s.excludedFolders)
    catalogCache = { at: Date.now(), folders }
    return folders
  }

  const listSuggestions = () => Array.from(suggestions.values()).filter(s => s.status === 'pending').sort((a, b) => b.ts - a.ts)
  const emitSuggestions = () => h.onSuggestions(listSuggestions())

  // ------------------------------------------------------------- downloads

  async function handleNewFile(info) {
    const s = settings()
    if (!fs.existsSync(info.path)) return null
    task('simulate', 'analyze', 75, info.name)
    const sourceUrl = info.sourceUrl ?? await readDownloadSource(info.path)
    const catalog = await getCatalog()
    const result = suggest({
      fileName: info.name, sourceUrl, courses: s.courses, catalog,
      learning: store.getLearning(), destinationRoots: s.destinationRoots
    })
    const sug = {
      id: uid(), ts: Date.now(), status: 'pending',
      file: { path: info.path, name: info.name, size: info.size, ext: extOf(info.name) },
      sourceUrl, aiAssisted: false,
      ...result
    }
    indexer.noteAdded({ path: info.path, name: info.name, dir: path.dirname(info.path), ext: sug.file.ext, size: info.size, mtime: info.mtime || Date.now() })

    if (s.autoMove && !sug.needsReview && sug.primary.confidence >= s.autoMoveThreshold) {
      try {
        const entry = await moveWithJournal(info.path, sug.primary.folder, { source: 'auto', course: sug.signals.course?.code || null, reason: sug.primary.reason, confidence: sug.primary.confidence })
        sug.status = 'moved'; sug.result = entry
        suggestions.set(sug.id, sug)
        h.onAutoMoved(entry, sug)
        return sug
      } catch { /* fall through to a manual suggestion */ }
    }

    suggestions.set(sug.id, sug)
    h.onNewSuggestion(sug)
    emitSuggestions()
    if (s.geminiApiKey) refineWithAi(sug).catch(() => {})
    return sug
  }

  async function refineWithAi(sug) {
    const s = settings()
    const ai = await gemini.pickFolderAI({
      apiKey: s.geminiApiKey, model: s.geminiModel, fileName: sug.file.name, signals: sug.signals,
      candidates: sug.candidatePaths, destinationRoot: s.destinationRoots[0] || '', sourceUrl: sug.sourceUrl
    })
    if (sug.status !== 'pending' || !ai || typeof ai.folder !== 'string') return
    const folder = path.resolve(ai.folder)
    const known = sug.candidatePaths.some(c => path.resolve(c) === folder)
    const underRoot = s.destinationRoots.some(r => isInside(folder, r))
    if (!known && !underRoot) return // never trust a path outside the user's chosen roots
    try { assertSafeDestination(folder) } catch { return }
    const conf = Math.max(0.05, Math.min(0.95, Number(ai.confidence) || 0.5))
    if (path.resolve(sug.primary.folder) !== folder) {
      sug.alternatives = [{ folder: sug.primary.folder, confidence: sug.primary.confidence, reason: sug.primary.reason }, ...sug.alternatives.filter(a => path.resolve(a.folder) !== folder)].slice(0, 6)
      sug.primary = { folder, isNewFolder: !fs.existsSync(folder), confidence: Math.min(conf, 0.9), reason: String(ai.reason || 'AI-suggested destination').slice(0, 200) }
    } else {
      sug.primary = { ...sug.primary, confidence: Math.max(sug.primary.confidence, Math.min(conf, 0.95)), reason: `${sug.primary.reason} · confirmed by AI` }
    }
    sug.aiAssisted = true
    sug.needsReview = sug.primary.confidence < 0.55
    emitSuggestions()
  }

  async function moveWithJournal(from, folder, meta) {
    const entry = await executeMove(from, folder, meta)
    store.addActivity(entry)
    indexer.noteMoved(from, entry.to)
    invalidateCatalog()
    h.onActivity(store.listActivity())
    return entry
  }

  async function acceptSuggestion(id, folder) {
    const sug = suggestions.get(id)
    if (!sug || sug.status !== 'pending') throw new Error('This suggestion is no longer available.')
    const target = folder || sug.primary.folder
    task('accept', 'move', 30, sug.file.name)
    const chosenDifferent = path.resolve(target) !== path.resolve(sug.primary.folder)
    const entry = await moveWithJournal(sug.file.path, target, {
      source: chosenDifferent ? 'download-manual' : 'download', course: sug.signals.course?.code || null,
      reason: chosenDifferent ? 'Destination chosen by you' : sug.primary.reason, confidence: chosenDifferent ? null : sug.primary.confidence
    })
    task('accept', 'save', 80, null)
    sug.status = 'moved'; sug.result = entry
    store.learn({ course: sug.signals.course?.code, ext: sug.file.ext, folder: path.dirname(entry.to) })
    emitSuggestions()
    return entry
  }

  function dismissSuggestion(id) {
    const sug = suggestions.get(id)
    if (sug) { sug.status = 'dismissed'; emitSuggestions() }
  }

  // ------------------------------------------------------------- search + organize

  async function search(text) {
    const t0 = Date.now()
    const s = settings()
    task('search', 'understand', 8, text.slice(0, 60))
    let plan = planQuery(text, { courses: s.courses })
    let aiError = null
    if (s.geminiApiKey && text.trim()) {
      try {
        const ai = await gemini.planQueryAI({ apiKey: s.geminiApiKey, model: s.geminiModel, text, courses: s.courses, today: new Date().toISOString().slice(0, 10) })
        plan = mergeAiPlan(plan, ai)
      } catch (e) { aiError = e.message }
    }
    task('search', 'scan', 45, null)
    await indexer.ensureFresh()
    task('search', 'rank', 80, `${indexer.status.count.toLocaleString()} files`)
    const { total, results } = searchFiles(indexer.files, plan)
    return { plan, total, results, indexed: indexer.status.count, tookMs: Date.now() - t0, aiError }
  }

  function suggestedFolderName(plan, text) {
    if (plan.courses?.length) return courseFolderName(plan.courses[0])
    const kw = (plan.groups || []).map(g => g[0]).filter(Boolean).slice(0, 3)
    const base = kw.length ? kw.join(' ') : text.trim().slice(0, 40)
    return base.replace(/[\\/:*?"<>|]/g, '').replace(/\b\w/g, c => c.toUpperCase()).trim() || 'Organized Files'
  }

  function organizePreview({ paths, text, destinationRoot, folderName: nameOverride }) {
    const s = settings()
    const root = destinationRoot || s.destinationRoots[0]
    if (!root) throw new Error('Choose a destination folder first.')
    assertSafeDestination(root)
    const plan = planQuery(text || '', { courses: s.courses })
    const cleaned = String(nameOverride || '').replace(/[\\/:*?"<>|]/g, '').trim()
    const folderName = cleaned || suggestedFolderName(plan, text || '')
    const files = paths.map(p => {
      const f = indexer.files.find(x => x.path === p)
      return f || { path: p, name: path.basename(p), size: 0 }
    })
    const { base, items } = planOrganize(files, { destinationRoot: root, folderName, courses: s.courses })
    return { destinationRoot: root, folderName, base, items }
  }

  async function organizeExecute({ items, label }) {
    const batchId = uid()
    const done = []; const failed = []
    task('organize', 'prepare', 4, `${items.length} files`)
    for (const [i, it] of items.entries()) {
      task('organize', 'move', 8 + Math.round((i / Math.max(items.length, 1)) * 84), `${it.fileName} (${i + 1}/${items.length})`)
      try {
        const entry = await moveWithJournal(it.from, path.dirname(it.to), { source: 'assistant', batchId, reason: label || 'Organized from search results' })
        done.push(entry)
      } catch (e) { failed.push({ fileName: it.fileName, error: e.message }) }
    }
    task('organize', 'save', 96, null)
    return { batchId, moved: done.length, failed }
  }

  async function undo(id, quiet) {
    const entry = store.getActivity(id)
    if (!entry) throw new Error('Activity entry not found.')
    if (!quiet) task('undo', 'restore', 40, entry.fileName)
    const r = await undoMove(entry)
    store.updateActivity(id, { status: 'undone', undoneAt: Date.now() })
    indexer.noteMoved(entry.to, r.restoredTo)
    invalidateCatalog()
    h.onActivity(store.listActivity())
    return r
  }

  async function undoBatch(batchId) {
    const entries = store.listActivity().filter(e => e.batchId === batchId && e.status === 'done')
    let ok = 0; const errors = []
    for (const [i, e] of entries.entries()) {
      task('undo', 'restore', Math.round((i / Math.max(entries.length, 1)) * 90) + 5, `${e.fileName} (${i + 1}/${entries.length})`)
      try { await undo(e.id, true); ok++ } catch (err) { errors.push(err.message) } }
    return { restored: ok, errors }
  }

  // ------------------------------------------------------------- lifecycle

  function syncWatcher() {
    const s = settings()
    const existing = s.watchedFolders.filter(f => { try { return fs.statSync(f).isDirectory() } catch { return false } })
    watcher.setPaused(s.paused)
    return watcher.sync(existing)
  }

  watcher.on('file', info => handleNewFile(info).catch(e => console.error('handleNewFile failed', e)))
  watcher.on('error', e => h.onWatchError(e))

  function start() {
    syncWatcher()
    setTimeout(() => indexer.build().catch(() => {}), 1500)
  }

  function updateSettings(patch) {
    const next = store.updateSettings(patch)
    if ('watchedFolders' in patch || 'paused' in patch) syncWatcher()
    if ('destinationRoots' in patch || 'excludedFolders' in patch) invalidateCatalog()
    if ('searchRoots' in patch || 'excludedFolders' in patch) indexer.build().catch(() => {})
    return next
  }

  function loadDemo() {
    task('demo', 'files', 15, 'Sample course files')
    const d = demo.createDemoWorkspace(documentsDir)
    task('demo', 'settings', 60, null)
    const s = settings()
    const merge = (list, add) => Array.from(new Set([...list, add]))
    const codes = new Set(s.courses.map(c => c.code))
    updateSettings({
      courses: [...s.courses, ...d.courses.filter(c => !codes.has(c.code))],
      destinationRoots: [d.destination, ...s.destinationRoots.filter(r => r !== d.destination)],
      watchedFolders: merge(s.watchedFolders, d.downloads),
      searchRoots: merge(s.searchRoots, d.root),
      demoLoaded: true, demoRoot: d.root
    })
    invalidateCatalog()
    task('demo', 'index', 85, null)
    indexer.build().catch(() => {})
    return d
  }

  function simulateDownload() {
    const s = settings()
    if (!s.demoLoaded) throw new Error('Load the demo workspace first.')
    task('simulate', 'create', 20, null)
    const r = demo.simulateDownload(path.join(s.demoRoot, 'Downloads'))
    task('simulate', 'detect', 60, null)
    return r
  }

  return {
    start, close: () => watcher.close(),
    settings, updateSettings,
    search, organizePreview, organizeExecute,
    listSuggestions, acceptSuggestion, dismissSuggestion, handleNewFile,
    undo, undoBatch, activity: () => store.listActivity(),
    rebuildIndex: () => indexer.build(), indexStatus: () => indexer.status,
    watching: () => watcher.active, syncWatcher,
    loadDemo, simulateDownload,
    testGemini: async (apiKey, model) => { task('ai', 'connect', 30, model || settings().geminiModel); return gemini.testKey({ apiKey, model: model || settings().geminiModel }) },
    _internals: { indexer, watcher, getCatalog }
  }
}

module.exports = { createCore }
