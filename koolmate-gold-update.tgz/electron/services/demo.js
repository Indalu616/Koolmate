'use strict'
/** Creates a self-contained sample workspace so the product can be demonstrated on any machine. */
const fs = require('fs')
const path = require('path')

function makePdf(title, lines = []) {
  const esc = s => String(s).replace(/[\\()]/g, m => '\\' + m)
  const content = ['BT', '/F1 22 Tf', '72 740 Td', `(${esc(title)}) Tj`, '/F1 12 Tf', ...lines.flatMap(l => ['0 -26 Td', `(${esc(l)}) Tj`]), 'ET'].join('\n')
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 5 0 R /Resources << /Font << /F1 4 0 R >> >> >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`
  ]
  let out = '%PDF-1.4\n'
  const offsets = []
  objs.forEach((o, i) => { offsets.push(Buffer.byteLength(out)); out += `${i + 1} 0 obj\n${o}\nendobj\n` })
  const xref = Buffer.byteLength(out)
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offsets.map(o => String(o).padStart(10, '0') + ' 00000 n \n').join('')
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`
  return Buffer.from(out, 'latin1')
}

const daysAgo = n => Date.now() - n * 86400000

const COURSES = [
  { code: 'CSC308', name: 'Operating Systems', keywords: ['os', 'operating systems'] },
  { code: 'CSC408', name: 'Distributed Systems', keywords: ['ds', 'distributed'] },
  { code: 'CSC302', name: 'Database Management', keywords: ['db', 'dbms', 'database'] },
  { code: 'SWE473', name: 'Software Maintenance and Evolution', keywords: ['maintenance', 'evolution'] },
  { code: 'GEN201', name: 'Genetics', keywords: [] }
]

const WORKSPACE = [
  ['University/CSC308 Operating Systems/Lectures/CSC308_Lecture03_Process_Scheduling.pdf', 41],
  ['University/CSC308 Operating Systems/Lectures/CSC308_Lecture04_Synchronization.pdf', 33],
  ['University/CSC308 Operating Systems/Assignments/CSC308_Assignment1_Threads.pdf', 30],
  ['University/CSC308 Operating Systems/Labs/CSC308_Lab02_File_Systems.pdf', 24],
  ['University/CSC308 Operating Systems/Exams/CSC308_Midterm_Past_Paper.pdf', 60],
  ['University/CSC408 Distributed Systems/Lectures/CSC408_Lecture05_Consensus_Paxos.pdf', 9],
  ['University/CSC408 Distributed Systems/Lectures/CSC408_Lecture06_Replication.pdf', 3],
  ['University/CSC408 Distributed Systems/Labs/CSC408_Lab02_PubSub_Broker.pdf', 12],
  ['University/CSC408 Distributed Systems/Assignments/CSC408_Assignment1_Clocks.pdf', 20],
  ['University/CSC302 Database Management/Lectures/CSC302_Lecture02_ER_Modeling.pdf', 45],
  ['University/CSC302 Database Management/Lectures/CSC302_Lecture05_Normalization.pdf', 6],
  ['University/CSC302 Database Management/Assignments/CSC302_Assignment2_SQL_Queries.pdf', 15],
  ['University/CSC302 Database Management/Exams/CSC302_Quiz1_Review.pdf', 28],
  ['University/SWE473 Software Maintenance and Evolution/Lectures/SWE473_Week2_Legacy_Code.pdf', 14],
  ['University/SWE473 Software Maintenance and Evolution/Projects/SWE473_Project_Proposal.pdf', 8],
  ['Personal/Invoices/electricity_bill_september.pdf', 35],
  // scattered files for the "organize" demo
  ['Scattered/genetics_lecture1_mendel.pdf', 52],
  ['Scattered/Genetics_Lab_Report_Drosophila.pdf', 40],
  ['Scattered/GEN201_Assignment3_Pedigrees.pdf', 18],
  ['Scattered/notes_genetics_midterm_review.pdf', 10],
  ['Scattered/holiday_packing_list.pdf', 70]
]

const DOWNLOAD_SAMPLES = [
  'CSC408_Lecture07_Replication_and_Consistency.pdf',
  'CSC302_Assignment3_Query_Optimization.pdf',
  'CSC308_Lab04_Memory_Management.pdf',
  'SWE473_Week3_Refactoring_Patterns.pdf',
  'GEN201_Lecture02_Mendelian_Genetics.pdf',
  'Signal.pdf'
]

function createDemoWorkspace(documentsDir) {
  const root = path.join(documentsDir, 'KoolMate Demo')
  for (const [rel, age] of WORKSPACE) {
    const file = path.join(root, rel)
    fs.mkdirSync(path.dirname(file), { recursive: true })
    const title = path.basename(file, '.pdf').replace(/_/g, ' ')
    if (!fs.existsSync(file)) fs.writeFileSync(file, makePdf(title, ['KoolMate demo document', 'Generated sample content.']))
    const t = new Date(daysAgo(age)); fs.utimesSync(file, t, t)
  }
  fs.mkdirSync(path.join(root, 'Downloads'), { recursive: true })
  return { root, destination: path.join(root, 'University'), downloads: path.join(root, 'Downloads'), courses: COURSES }
}

let sampleIndex = 0
function simulateDownload(downloadsDir, name) {
  const fileName = name || DOWNLOAD_SAMPLES[sampleIndex++ % DOWNLOAD_SAMPLES.length]
  fs.mkdirSync(downloadsDir, { recursive: true })
  let target = path.join(downloadsDir, fileName)
  if (fs.existsSync(target)) {
    const ext = path.extname(fileName)
    target = path.join(downloadsDir, `${path.basename(fileName, ext)} (${Date.now() % 1000})${ext}`)
  }
  const title = path.basename(fileName, '.pdf').replace(/_/g, ' ')
  // write in two steps so the watcher's "wait until the download finishes" logic is exercised for real
  const buf = makePdf(title, ['Simulated download', 'Created by KoolMate demo tools.'])
  fs.writeFileSync(target, buf.subarray(0, 200))
  setTimeout(() => { try { fs.appendFileSync(target, buf.subarray(200)) } catch { /* ignore */ } }, 400)
  return target
}

module.exports = { createDemoWorkspace, simulateDownload, makePdf, COURSES, DOWNLOAD_SAMPLES }
